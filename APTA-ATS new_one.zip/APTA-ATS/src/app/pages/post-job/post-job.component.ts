import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-job',
  templateUrl: './post-job.component.html',
  styleUrls: ['./post-job.component.scss']
})
export class PostJobComponent implements OnInit {
  selectCard = false;
  add_interview = false;
  interview_rounds = [];
  jobs = ['Linked In', 'Monster', 'Naukri', 'Indeed', 'Freshers World', 'Indeed', 'Indeed', 'Indeed'];
  TemplateForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private router: Router
  ) { }
  ngOnInit() {
    this.inItForm();
  }
  inItForm() {
    this.TemplateForm = this.fb.group({
      assesmentsForm: this.fb.array([this.assesmentsArray()]),
      interview_name: ''
    });
  }
  assesmentsArray() {
    return this.fb.group({
      ass_name: '',
    })
  }
  get getFormArray() {
    return<FormArray> this.TemplateForm.get('assesmentsForm') ;
  }
  addNewRow() {
    this.getFormArray.push(this.assesmentsArray());
  }
  deleteRow(index: number) {
    this.getFormArray.removeAt(index);
  }
checkbox(event) {
  console.log(event)
}
addInterview() {
  this.add_interview = true;
  const value = this.TemplateForm.get('interview_name').value;
  this.interview_rounds.push(value);
  this.TemplateForm.reset();
  this.add_interview = false;
}
deleteInterview(i) {
  this.interview_rounds.splice(i, 1)
}
jobPosting() {
  this.router.navigate(['./post-job'])
}
}
