import { Component, OnInit } from '@angular/core';
import {COMMA, ENTER, DELETE} from '@angular/cdk/keycodes';
import {NgbDate, NgbCalendar, NgbDateParserFormatter} from '@ng-bootstrap/ng-bootstrap';
import {MatChipInputEvent} from '@angular/material/chips';
import { FormBuilder, FormGroup } from '@angular/forms';

export interface Fruit {
  name: string;
}
@Component({
  selector: 'app-job-posting',
  templateUrl: './job-posting.component.html',
  styleUrls: ['./job-posting.component.scss']
})
export class JobPostingComponent implements OnInit {
  freeBoards = true;
// shills
visible = true;
selectable = true;
removable = true;
addOnBlur = true;
readonly separatorKeysCodes: number[] = [ENTER, COMMA];
fruits: Fruit[] = [
  {name: 'Java'},
  {name: 'Python'},
  {name: 'SQL'},
];
add_interview = false;
interview_rounds = [];
  jobs = ['Linked In', 'Monster', 'Naukri', 'Indeed', 'Freshers World'];
  TemplateForm: FormGroup;
// end
  // date picker
  hoveredDate: NgbDate;
  dateSelect = false;
  fromDate: NgbDate;
  toDate: NgbDate;

  constructor(private calendar: NgbCalendar,
    public formatter: NgbDateParserFormatter,
    private fb: FormBuilder) {
    this.fromDate = calendar.getToday();
    this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
  }

  ngOnInit() {
    this.inItForm();
    // Get the element with id="defaultOpen" and click on it
    // document.getElementById('defaultOpen').click();
  }
  inItForm() {
    this.TemplateForm = this.fb.group({
      interview_name: ''
    });
  }
  onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
  }

  isHovered(date: NgbDate) {
    return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
  }

  isInside(date: NgbDate) {
    return date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return date.equals(this.fromDate) || date.equals(this.toDate) || this.isInside(date) || this.isHovered(date);
  }

  validateInput(currentValue: NgbDate, input: string): NgbDate {
    const parsed = this.formatter.parse(input);
    return parsed && this.calendar.isValid(NgbDate.from(parsed)) ? NgbDate.from(parsed) : currentValue;
  }


  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.fruits.push({name: value.trim()});
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(fruit: Fruit): void {
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }
  addInterview() {
    this.add_interview = true;
    const value = this.TemplateForm.get('interview_name').value;
    this.interview_rounds.push(value);
    this.TemplateForm.reset();
    this.add_interview = false;
  }
  deleteInterview(i) {
    this.interview_rounds.splice(i, 1)
  }

}
