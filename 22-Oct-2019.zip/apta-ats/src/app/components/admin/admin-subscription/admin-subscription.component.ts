import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-subscription',
  templateUrl: './admin-subscription.component.html',
  styleUrls: ['./admin-subscription.component.scss']
})
export class AdminSubscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
